/* ========================================
 * ULB - Digital Electronic : Project 2020 
 * 
 * Mathias Hanquiniaux
 * Tanguy Snoeck
 * Vladimir Tulcinsky
 *
 * ========================================
*/

#include "project.h"

void keypadInit (void);
uint8_t keypadScan(void);

/* [] END OF FILE */
